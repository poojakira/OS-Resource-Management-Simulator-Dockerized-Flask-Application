 #student name: pooja kiran
 #student id: 1234444082
 #date: 11-30-2024

from flask import Flask, render_template, request, redirect, url_for

# Simulate hardware resources (kitchen tools)
hardware_resources = {
    "Stove": "Available",
    "Oven": "Available",
    "Mixer": "Available",
    "Knife": "Available"
}

# Flask Web Interface
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html', resources=hardware_resources)

# Define the route with a URL parameter
@app.route('/resource/<tool>', methods=['GET'])
def request_resource_web(tool):
    if hardware_resources.get(tool) == "Available":
        hardware_resources[tool] = "Occupied"
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8000)